package centre_Sportif5Servlet;

public class CentreSportifConstantes {
	public final static int CONNECTE = 0;
	public final static int ACCES_RESPONSABLE = 1;
	public final static int ACCES_MEMBRE= 2;
	public final static int MEMBRE_CAPITAINE= 3;
	

}
